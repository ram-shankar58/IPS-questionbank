#include <stdio.h>
int main() {
    int i,j,k;
    int a[3][3];
    int b[3][3];
    int c[3][3];
    for (i=0;i<3;i++) {
        for (j=0;j<3;j++) {
            scanf("%d",&a[i][j]);
        }
    }
    for (j=0;j<3;j++) {
        for (i=0;i<3;i++) {
            scanf("%d",&b[j][i]);
        }
    }
    for (i=0;i<3;i++) {
        for (j=0;j<3;j++) {
            c[i][j]=0;
            for (k=0;k<3;k++) {
                c[i][j] = c[i][j] + a[i][k]*b[k][j];
            }
        }
    }
    for (i=0;i<3;i++) {
        for (j=0;j<3;j++) {
            printf("%d\n",c[i][j]);
        }
    }
    return 0;
}
